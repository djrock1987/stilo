<div class="step-module">
  <p>PASO 5</p>
</div>

<div class="title-module">
  <h2>ESCOJE TUS LENTES TRANSITIONS ® <br/>DE USO DIARIO</h2>
</div>

<div class="info-content">

  <div class="selection-steps select-image-source">

    <div class="large-6 medium-6 transitions-selection">
      <div class="filter-selection" id="transitions-signature" data-type="Signature">
        <h3>Transitions Signature</h3>
        <ul>
          <li>Lentes de uso diario con el nivel de tintes adecuados en exteriores.</li>
          <li>Tan claros como los lentes comunes en exteriores.</li>
          <li>Lentes Transitions® de uso diario con gran velocidad de desactivación.</li>
        </ul>
      </div>
    </div>

    <div class="large-6 medium-6 transitions-selection">
      <div class="filter-selection" id="transitions-xtractive" data-type="XTRActive">
        <h3>Transitions Signature</h3>
        <ul>
          <li>Los lentes Transitions de uso diario más oscuros.</li>
          <li>Presentan un leve tinte en interiores para brindar mayor confort.</li>
          <li>Se oscurcen moderadamente detrás del parabrisas y brindan una tonalidad confortable para conducir.</li>
        </ul>
      </div>
    </div>

  </div>
</div>