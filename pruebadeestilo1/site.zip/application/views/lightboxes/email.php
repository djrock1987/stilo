<div class="lightbox" id="emailFormLigthbox">
  <form action="" class="ajaxForms" id="emailForm">
    <input type="hidden" name="image_url" />
    <input type="hidden" name="action" value="emailForm" />
    <input type="hidden" name="object_id" value="emailForm" />
    <div class="row">
      <div class="columns-large-12"><label for=""><input type="text" name="nombre_amigo" placeholder="Nombre de tu amigo" required="" /></label></div>
    </div>

    <div class="row">
      <div class="columns-large-12"><label for=""><input type="email" name="email_amigo" placeholder="E-mail de tu amigo" required="" /></label></div>
    </div>

    <div class="row">
      <div class="columns-large-12"><label for=""><input type="text" name="nombre" placeholder="Tu nombre" required="" /></label></div>
    </div>

    <div class="row">
      <div class="columns-large-12"><label for=""><input type="text" name="email" placeholder="Tu E-mail" required="" /></label></div>
    </div>

    <div class="row">
      <div class="columns-large-12"><label for=""><input type="submit" /></label></div>
    </div>

  </form>
</div>