<p><?php echo sprintf("Hola %s", $nombre_amigo); ?></p>

<p><?php echo sprintf("%s se ha probado unas fotos en Transitions Lentes Adaptables", $nombre); ?></p>

<p><img src="<?php echo $image_url ?>" alt="" /></p>

<p><?php echo sprintf("Pruebalas tu también  <a href='%s'>aquí</a>", site_url()); ?></p>