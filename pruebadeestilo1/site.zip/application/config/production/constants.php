<?php

define('FACEBOOK_APP_ID', '622845417856607');
define('FACEBOOK_APP_SECRET', '9bf409199bcb1403e8eb2c2f49d2250f');
define('FACEBOOK_NAMESPACE', 'transitionslentesada');