<?php

define('FACEBOOK_APP_ID', '622848404522975');
define('FACEBOOK_APP_SECRET', '6a6ed16d89fed42ad60d1f9a4d29e168');
define('FACEBOOK_NAMESPACE', 'transitionslentesloc');
