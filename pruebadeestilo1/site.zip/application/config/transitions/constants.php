<?php

define('FACEBOOK_APP_ID', '623605397780609');
define('FACEBOOK_APP_SECRET', 'c988ab19ad362814e1fad5a245708108');
define('FACEBOOK_NAMESPACE', 'transitionslentestxt');